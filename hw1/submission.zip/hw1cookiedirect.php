<?php include 'hw1funcs.php'?>
<!DOCTYPE html>
<html>
 <head>
  <title>Homework 1</title>
 </head>
 <body>
<?php
	//this literally exists for the sake of the cookie set
	$newclicked = aftersubmittingnew();
	$editclicked = aftersubmittingedit();
	header("Location: hw1.php");
?>


 </body>
</html>
